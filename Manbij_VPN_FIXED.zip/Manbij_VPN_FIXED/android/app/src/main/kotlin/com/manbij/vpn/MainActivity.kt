package com.manbij.vpn

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
